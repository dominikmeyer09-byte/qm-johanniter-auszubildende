QM Johanniter Auszubildende – Version 7

Deployment:
- Upload index.html to your GitHub repository root.
- Vercel can deploy the repository automatically.
- The app continues to use the existing Supabase project/database.

Version 7 updates:
- New QM Johanniter Auszubildende branding/header
- Separate visual statistics for every QM question
- Stacked Ja/Teilweise/Nein percentage bars
- Improved deployment detail view with preserved free-text answers
- Existing delete, filters, CSV/PDF, admin and question management retained

Security:
- Only the Supabase publishable key is included in the browser.
- Never publish the Supabase secret/service-role key.
