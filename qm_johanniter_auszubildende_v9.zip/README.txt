QM Johanniter Auszubildende – V9

Neue Funktionen:
- Passwort vergessen / Passwort zurücksetzen per E-Mail
- Passwort-Anzeige mit Anzeigen/Verbergen-Schaltfläche
- Neue Rolle Praxisanleiter
- Admin/Praxisanleiter können Azubis und Praxisanleiter über Einladungen anlegen
- Praxisanleiter erhalten Zugriff auf Statistik, Einsätze, Azubis und QM-Fragen wie die bisherige Admin-Rolle
- Azubis behalten die getrennte Ansicht ihrer eigenen Daten
- Bestehende Supabase-Datenbank und vorhandene Einsätze bleiben erhalten

Deployment:
index.html direkt in das GitHub-Repository legen. Vercel erstellt bei jedem Commit automatisch ein neues Deployment.

Wichtig für Passwort-Reset:
In Supabase Authentication -> URL Configuration muss die aktuelle App-URL als Site URL bzw. Redirect URL erlaubt sein, z. B.:
https://qm-johanniter-auszubildende.vercel.app
https://qm-johanniter-auszubildende.vercel.app/**
